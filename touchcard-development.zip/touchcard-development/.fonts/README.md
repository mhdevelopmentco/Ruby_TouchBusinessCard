# Touchcard Fonts

These fonts are used for Chrome Headless rendering.

This directory is automatically copied to Heroku on deploy.

We're only pulling in the fonts we actually need.

