module.exports = {
  module: {
    rules: [
      {
        // No longer loading .html, using .vue instead
        // test: /\.html$/,
        // exclude: /node_modules/,
        // use: {loader: 'html-loader'}
      }
    ]
  }
}