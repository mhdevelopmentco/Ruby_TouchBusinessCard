class GdprCustomersDataRequest < ApplicationRecord
end
