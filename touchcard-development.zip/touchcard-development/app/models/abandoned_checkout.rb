# TODO: Unused Automations Code
#
# class AbandonedCheckout < CardOrder
#   after_initialize :ensure_defaults
#
#   def ensure_defaults
#     super
#   end
#
#   def name
#     "Abandoned checkout card"
#   end
#
#   def description
#     "Engage customers that started but later abandoned their checkout!"
#   end
# end
