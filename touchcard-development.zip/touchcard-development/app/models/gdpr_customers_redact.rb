class GdprCustomersRedact < ApplicationRecord
end
