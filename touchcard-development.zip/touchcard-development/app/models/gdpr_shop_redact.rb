class GdprShopRedact < ApplicationRecord
end
