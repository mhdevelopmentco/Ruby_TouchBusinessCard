class PostSaleOrder < CardOrder
  def name
    "Post sale card"
  end

  def description
    "Send postcard to you customer after they made purchase!"
  end
end
