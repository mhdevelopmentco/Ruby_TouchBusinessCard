ActiveAdmin.register_page "Dashboard" do
  menu false

end
