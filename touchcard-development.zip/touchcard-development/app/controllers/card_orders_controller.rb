class CardOrdersController < BaseController

  # def create
  #   puts params.to_yaml
  #   CardOrder.create(type: 'PostSaleOrder', shop: @current_shop);
  #   redirect_to root_path
  # end
  #
  #
  # def update
  #   puts params.to_yaml
  #   redirect_to edit_automation_path(id: params[:id])
  #   # redirect_to edit_automation_path(CardOrder.find(params[:id]))
  # end

  # def destroy
  #
  # end

end
