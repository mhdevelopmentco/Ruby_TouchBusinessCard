require 'test_helper'

class FaqControllerTest < ActionController::TestCase
  # test "the truth" do
  #   assert true
  # end
end
